const tablica_kategorii_i_piosenek = [
    {
      Kategoria: "Powiew lata",
      Piosenka: "Wakacje znów będą wakacje"
    },
    {
      Kategoria: "Zazwyczaj bez łez",
      Piosenka: "Chłopaki nie płaczą"
    },
    {
      Kategoria: "Morskie opowieść",
      Piosenka: "Morskie opowieść"
    },
    {
      Kategoria: "Bojowa szanta",
      Piosenka: "Bitwa (szanta)"
    },
    {
      Kategoria: "Odkrywcy",
      Piosenka: "Drobnostka z Vaiany"
    },
    {
      Kategoria: "Dla każdego",
      Piosenka: "We are the champion"
    },
    {
      Kategoria: "Nie dla Kubusia Puchatka",
      Piosenka: "Pszczółka Maja"
    },
    {
      Kategoria: "Kawa czy herbata",
      Piosenka: "Kawka na wynos"
    },
    {
      Kategoria: "Strata",
      Piosenka: "O Ela straciłaś przyjaciela"
    },
    {
      Kategoria: "Prestiż w górach",
      Piosenka: "Zakopane"
    },
    {
      Kategoria: "World of tanks",
      Piosenka: "4 pancerni i pies"
    },
    {
      Kategoria: "Działania na liczbach ujemnych",
      Piosenka: "Mniej niż 0"
    },
    {
      Kategoria: "Marzenia zawodowe",
      Piosenka: "Chciałbym być marynarzem"
    },
    {
      Kategoria: "Dla murarza",
      Piosenka: "Czerwony jak cegła"
    },
    {
      Kategoria: "Nic nie muszę, wszystko mogę",
      Piosenka: "Mam tę moc"
    },
    {
      Kategoria: "Zimowe szaleństwo",
      Piosenka: "Ulepimy dziś bałwana"
    },
    {
      Kategoria: "Warzywna piosenka",
      Piosenka: "Ogórek zielony ma garniturek"
    },
    {
      Kategoria: "Kolejowa piosenka",
      Piosenka: "Nic nie robić nie mieć zmartwień"
    },
    {
      Kategoria: "Skok",
      Piosenka: "Gumisie"
    },
    {
      Kategoria: "Zero trosk",
      Piosenka: "Hakuna matata"
    }
  ];

  export default tablica_kategorii_i_piosenek;
  